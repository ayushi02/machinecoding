package com.company.exception;

import com.company.enums.ExceptionEnum;

public class ConferenceManagementException extends Exception{
   // private ExceptionEnum exceptionEnum;


    public ConferenceManagementException(ExceptionEnum exceptionEnum) {
        super(exceptionEnum.getErrorMessage());
       // this.exceptionEnum = exceptionEnum;
    }
}
