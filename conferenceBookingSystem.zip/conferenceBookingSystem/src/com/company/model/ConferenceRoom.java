package com.company.model;

import java.util.ArrayList;
import java.util.List;

public class ConferenceRoom {
    private String confRoomId;
    private List<Slot> bookedSlots;
    private int bookSlotStart;
    private int bookSlotEnd;

    public ConferenceRoom(String confRoomId) {
        this.confRoomId = confRoomId;
        this.bookedSlots = new ArrayList<>();
        this.bookSlotStart = -1;
        this.bookSlotEnd = -1;
    }

    public String getConfRoomId() {
        return confRoomId;
    }

    public void setConfRoomId(String confRoomId) {
        this.confRoomId = confRoomId;
    }

    public int getBookSlotStart() {
        return bookSlotStart;
    }

    public void setBookSlotStart(int bookSlotStart) {
        this.bookSlotStart = bookSlotStart;
    }

    public int getBookSlotEnd() {
        return bookSlotEnd;
    }

    public void setBookSlotEnd(int bookSlotEnd) {
        this.bookSlotEnd = bookSlotEnd;
    }

    public List<Slot> getBookedSlots() {
        return bookedSlots;
    }

    public void setBookedSlots(List<Slot> bookedSlots) {
        this.bookedSlots = bookedSlots;
    }

    @Override
    public String toString() {
        return "ConferenceRoom{" +
                "confRoomId='" + confRoomId + '\'' +
                ", bookedSLots=" + bookedSlots +
                ", bookSlotStart=" + bookSlotStart +
                ", bookSlotEnd=" + bookSlotEnd +
                '}';
    }
}
