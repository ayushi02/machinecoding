package com.company.model;

import com.company.model.ConferenceRoom;

import java.util.ArrayList;
import java.util.List;

public class Floor {
    private String floorName;
    private List<ConferenceRoom> conferenceRoomList;

    public Floor(String floorName) {
        this.floorName = floorName;
        this.conferenceRoomList = new ArrayList<>();
    }

    public String getFloorName() {
        return floorName;
    }

    public void setFloorName(String floorName) {
        this.floorName = floorName;
    }

    public List<ConferenceRoom> getConferenceRoomList() {
        return conferenceRoomList;
    }

    public void setConferenceRoomList(List<ConferenceRoom> conferenceRoomList) {
        this.conferenceRoomList = conferenceRoomList;
    }

    @Override
    public String toString() {
        return "Floor{" +
                "floorName='" + floorName + '\'' +
                ", conferenceRoomList=" + conferenceRoomList +
                '}';
    }
}
