package com.company.model;

public class BookingData {
    private int startTime;
    private int endTime;
    private Building building;
    private Floor floor;
    private ConferenceRoom conferenceRoom;

    public BookingData(int startTime, int endTime, Building building, Floor floor, ConferenceRoom conferenceRoom) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.building = building;
        this.floor = floor;
        this.conferenceRoom = conferenceRoom;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public Building getBuilding() {
        return building;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }

    public Floor getFloor() {
        return floor;
    }

    public void setFloor(Floor floor) {
        this.floor = floor;
    }

    public ConferenceRoom getConferenceRoom() {
        return conferenceRoom;
    }

    public void setConferenceRoom(ConferenceRoom conferenceRoom) {
        this.conferenceRoom = conferenceRoom;
    }

    @Override
    public String toString() {
        return "BookingData{" +
                "startTime=" + startTime +
                ", endTime=" + endTime +
                ", building=" + building +
                ", floor=" + floor +
                ", conferenceRoom=" + conferenceRoom +
                '}';
    }
}
