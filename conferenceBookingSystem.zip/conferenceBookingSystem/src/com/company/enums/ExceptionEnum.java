package com.company.enums;

public enum ExceptionEnum {
    BUILDING_ALREADY_ADDED("ERROR1", "Building ALready added"),
    BUILDING_DOES_NOT_EXIST("ERROR2", "Building does not exist"),
    FLOOR_ALREADY_ADDED("ERROR3", "Floor aldready added"),
    FLOOR_DOES_NOT_EXIST("ERROR4", "Floor does not exist"),
    CONFROOM_DOES_NOT_EXIST("ERROR5", "ConfRoom does not exist"),
    CONFROOM_ALREADY_ADDED("ERROR6", "ConfRoom aldready added"),
    NO_BOOKED_SLOT_FOUND("ERRO7","No book slot found"),
    NO_CONFROOM_FOUND("EOOR8", "No conf room found");

    private String errorCode;
    private String errorMessage;

    ExceptionEnum(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
