package com.company.service;

import com.company.dao.BuildingDAO;

public class ConferenceRoomManagementService {
    private static ConferenceRoomManagementService conferenceRoomManagementService = null;
    BuildingDAO buildingDAO = BuildingDAO.getInstance();

    private ConferenceRoomManagementService()
    {

    }

    public static ConferenceRoomManagementService getInstance()
    {
        if(conferenceRoomManagementService == null)
        {
            conferenceRoomManagementService = new ConferenceRoomManagementService();
        }
        return conferenceRoomManagementService;
    }

    public void addBuilding(String name)
    {
        try{
            buildingDAO.addBuilding(name);
            System.out.println("Building added successfully "+name);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void addFloor(String buildingname, String floorName)
    {
        try{
            buildingDAO.addFloor(buildingname, floorName);
            System.out.println("floor added successfully for "+buildingname+" "+floorName);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void addConfRoom(String buildingname, String floorName, String confRoom)
    {
        try{
            buildingDAO.addConfRoom(buildingname, floorName, confRoom);
            System.out.println("confroom added successfully for "+buildingname+" "+floorName+" "+confRoom);

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void bookSlot(int startTime, int endTime, String buildingName, String floorName, String confid)
    {
        try{
            if(!validdata(startTime, endTime))
            {
                System.out.println("Invalid start Time or end Time");
            }
           if(buildingDAO.validateAndbookConfRoom(startTime, endTime, buildingName, floorName, confid))
           {
               System.out.println("Booking done successfully");
           }
           else
           {
               System.out.println("Slot already booked");
           }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    public Boolean validdata(int startTime, int endTime)
    {
        if(startTime>=endTime)
        {
            return Boolean.FALSE;
        }
        if(startTime<0 || startTime>23)
        {
            return Boolean.FALSE;
        }
        if(endTime<0 || endTime>23)
        {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public void cancelSlot(int startTime, int endTime, String buildingName, String floorName, String confid)
    {
        try{
            if(!validdata(startTime, endTime))
            {
                System.out.println("Invalid start Time or end Time");
            }
            if(buildingDAO.validateAndCancelSlot(startTime, endTime, buildingName, floorName, confid))
            {
                System.out.println("Booking cancelled successfully");
            }
            else
            {
                System.out.println("Cannot cancel Booking: no booking found");
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void listBooking(String buildingName, String floorName)
    {
        try {
            buildingDAO.printBookedSlot(buildingName, floorName);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    public void searchRoom(int startTime, int endTime, String buildingName, String floorName)
    {

        try{
            buildingDAO.validateAndCheckConfRoom(startTime, endTime, buildingName, floorName);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
