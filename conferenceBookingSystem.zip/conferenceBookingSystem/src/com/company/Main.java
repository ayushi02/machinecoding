package com.company;

import com.company.exception.ConferenceManagementException;
import com.company.service.ConferenceRoomManagementService;

public class Main {

    public static void main(String[] args) {
        ConferenceRoomManagementService conferenceRoomManagementService = ConferenceRoomManagementService.getInstance();

        conferenceRoomManagementService.addBuilding("flipkart1");
        conferenceRoomManagementService.addFloor("flipkart1", "FirstFloor");
        conferenceRoomManagementService.addConfRoom("flipkart1", "FirstFloor", "c1");
        conferenceRoomManagementService.addConfRoom("flipkart1", "FirstFloor", "c2");

        conferenceRoomManagementService.bookSlot(1, 5, "flipkart1", "FirstFloor", "c1");

        conferenceRoomManagementService.bookSlot(1, 2, "flipkart1", "FirstFloor", "c2");

//        conferenceRoomManagementService.bookSlot(2, 3, "flipkart1", "FirstFloor", "c1");

//        conferenceRoomManagementService.bookSlot(3, 6, "flipkart1", "FirstFloor", "c1");

        //conferenceRoomManagementService.bookSlot(2, 6, "flipkart1", "FirstFloor", "c1");

        //conferenceRoomManagementService.cancelSlot(1,5,"flipkart1", "FirstFloor", "c1");

        conferenceRoomManagementService.listBooking("flipkart1", "FirstFloor");

        conferenceRoomManagementService.searchRoom(2, 4, "flipkart1", "FirstFloor");

        conferenceRoomManagementService.cancelSlot(1,5,"flipkart1", "FirstFloor", "c1");

        conferenceRoomManagementService.searchRoom(2, 4, "flipkart1", "FirstFloor");
    }
}
