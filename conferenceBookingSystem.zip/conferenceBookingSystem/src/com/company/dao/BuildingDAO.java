package com.company.dao;

import com.company.enums.ExceptionEnum;
import com.company.exception.ConferenceManagementException;
import com.company.model.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BuildingDAO {
    private static BuildingDAO buildingDAO = null;
    private Map<String, Building> buildingMap = new HashMap<>();
    //private Map<Integer, BookingData> bookingDataMap = new HashMap<>();

    private BuildingDAO()
    {

    }

    public static BuildingDAO getInstance()
    {
        if(buildingDAO == null)
        {
            buildingDAO = new BuildingDAO();
        }
        return buildingDAO;
    }

    public Boolean addBuilding(String buildingName) throws ConferenceManagementException
    {
        if(ifBuildingExists(buildingName))
        {
            throw new ConferenceManagementException(ExceptionEnum.BUILDING_ALREADY_ADDED);
        }
        Building building = new Building(buildingName);
        buildingMap.put(buildingName, building);
        return Boolean.TRUE;
    }

    public Boolean addFloor(String buildingName, String floorName) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }
        if(checkFloorExists(buildingName, floorName))
        {
            throw new ConferenceManagementException(ExceptionEnum.FLOOR_ALREADY_ADDED);
        }

        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        floorList.add(new Floor(floorName));

        return Boolean.TRUE;

    }

    public Boolean addConfRoom(String buildingName, String floorName, String confRoomName) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }
        if(!checkFloorExists(buildingName, floorName))
        {
            throw new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }
        if(checkConfRoomExists(buildingName, floorName, confRoomName))
        {
            throw new ConferenceManagementException(ExceptionEnum.CONFROOM_ALREADY_ADDED);
        }

        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        for(Floor floor: floorList)
        {
            if(floor.getFloorName().equals(floorName))
            {
                List<ConferenceRoom> conferenceRoomList = floor.getConferenceRoomList();

                conferenceRoomList.add(new ConferenceRoom(confRoomName));

                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    public Boolean ifBuildingExists(String buildingName)
    {
        if(buildingMap!= null && buildingMap.containsKey(buildingName))
        {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean checkFloorExists(String buildingName, String floorName)
    {
        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        for( Floor floor: floorList)
        {
            if(floor.getFloorName().equals(floorName))
            {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    public Boolean checkConfRoomExists(String buildingName, String floorName, String confRoomname)
    {
        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        for( Floor floor: floorList)
        {
            if(floor.getFloorName().equals(floorName))
            {
                List<ConferenceRoom> conferenceRoomList = floor.getConferenceRoomList();

                for(ConferenceRoom conferenceRoom: conferenceRoomList)
                {
                    if(conferenceRoom.getConfRoomId().equals(confRoomname))
                    {
                        return Boolean.TRUE;
                    }
                }
            }
        }
        return Boolean.FALSE;
    }

    public Boolean validateAndbookConfRoom(int startTime, int endTime, String buildingName, String floorName,
                                            String confid) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }

        if(!checkFloorExists(buildingName, floorName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }

        if(!checkConfRoomExists(buildingName, floorName, confid))
        {
            throw  new ConferenceManagementException(ExceptionEnum.CONFROOM_DOES_NOT_EXIST);
        }

        ConferenceRoom conferenceRoom = getConfRoom(buildingName, floorName, confid);

        if(conferenceRoom == null)
        {
            throw  new ConferenceManagementException(ExceptionEnum.CONFROOM_DOES_NOT_EXIST);
        }
        else
        {
            return bookSlot(conferenceRoom, startTime, endTime);

        }

    }

    public Boolean bookSlot(ConferenceRoom conferenceRoom, int startTime, int endTime)
    {
        List<Slot> bookedSlots = conferenceRoom.getBookedSlots();

        if(bookedSlots ==  null || bookedSlots.size()== 0)
        {
            bookedSlots.add(new Slot(startTime, endTime));
            return Boolean.TRUE;
        }
        else
        {
            for(Slot slot: bookedSlots)
            {
                if((endTime>slot.getStartTime() && endTime <slot.getEndTime()) ||
                        (startTime>slot.getStartTime() && startTime< slot.getEndTime()))
                {
                   return Boolean.FALSE;
                }
            }
        }
        bookedSlots.add(new Slot(startTime, endTime));
        return Boolean.TRUE;
    }

    public ConferenceRoom getConfRoom(String buildingName, String floorName,
                                      String confid)
    {
        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        for( Floor floor: floorList)
        {
            if(floor.getFloorName().equals(floorName))
            {
                List<ConferenceRoom> conferenceRoomList = floor.getConferenceRoomList();

                for(ConferenceRoom conferenceRoom: conferenceRoomList)
                {
                    if(conferenceRoom.getConfRoomId().equals(confid))
                    {
                        return conferenceRoom;
                    }
                }
            }
        }
        return null;
    }

    public Boolean validateAndCancelSlot(int startTime, int endTime, String buildingName, String floorName,
                           String confid) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }

        if(!checkFloorExists(buildingName, floorName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }

        if(!checkConfRoomExists(buildingName, floorName, confid))
        {
            throw  new ConferenceManagementException(ExceptionEnum.CONFROOM_DOES_NOT_EXIST);
        }

        ConferenceRoom conferenceRoom = getConfRoom(buildingName, floorName, confid);

        if(conferenceRoom == null)
        {
            throw  new ConferenceManagementException(ExceptionEnum.CONFROOM_DOES_NOT_EXIST);
        }
        else
        {
            return cancelSlot(conferenceRoom, startTime, endTime);

        }
    }

    public Boolean cancelSlot(ConferenceRoom conferenceRoom, int startTime, int endTime)
    {
        List<Slot> bookedSlots = conferenceRoom.getBookedSlots();

        if(bookedSlots ==  null || bookedSlots.size()== 0)
        {
            return Boolean.FALSE;
        }
        else
        {
            for(Slot slot: bookedSlots)
            {
                if(slot.getStartTime() == startTime && slot.getEndTime() == endTime)
                {
                    bookedSlots.remove(slot);
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }

    public void printBookedSlot(String buildingName, String floorName) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }

        if(!checkFloorExists(buildingName, floorName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }

        Floor floor = getFloor(buildingName, floorName);
        if(floor == null)
        {
            throw  new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }
        List<ConferenceRoom> conferenceRoomList = floor.getConferenceRoomList();

        if(conferenceRoomList == null || conferenceRoomList.size()==0)
        {
            throw  new ConferenceManagementException(ExceptionEnum.NO_BOOKED_SLOT_FOUND);
        }
        System.out.println("printing slots for "+buildingName+" "+floorName);
        for(ConferenceRoom conferenceRoom: conferenceRoomList)
        {
            printBookedSlot(conferenceRoom);
        }
    }

    public Floor getFloor(String buildingName, String floorName)
    {
        Building building = buildingMap.get(buildingName);
        List<Floor> floorList = building.getFloorList();

        for(Floor floor: floorList)
        {
            if(floor.getFloorName().equals(floorName))
            {
                return floor;
            }
        }
        return null;
    }

    public void printBookedSlot(ConferenceRoom conferenceRoom)
    {
        System.out.println("confid "+conferenceRoom.getConfRoomId());
        if(conferenceRoom.getBookedSlots()== null || conferenceRoom.getBookedSlots().size()==0)
        {
            System.out.println("no slots found");
            return;
        }
        else
        {
            for(Slot slot: conferenceRoom.getBookedSlots())
            {
                System.out.println(slot);
            }
        }
    }

    public void validateAndCheckConfRoom(int startTime, int endTime, String buildingName, String floorName) throws ConferenceManagementException
    {
        if(!ifBuildingExists(buildingName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.BUILDING_DOES_NOT_EXIST);
        }

        if(!checkFloorExists(buildingName, floorName))
        {
            throw  new ConferenceManagementException(ExceptionEnum.FLOOR_DOES_NOT_EXIST);
        }

        List<ConferenceRoom> conferenceRoomList = getFloor(buildingName, floorName).getConferenceRoomList();

        if(conferenceRoomList== null || conferenceRoomList.size()==0)
        {
            throw  new ConferenceManagementException(ExceptionEnum.NO_CONFROOM_FOUND);
        }

        System.out.println("rooms available");
        for(ConferenceRoom conferenceRoom: conferenceRoomList)
        {
            if(checkSlot(conferenceRoom, startTime, endTime))
            {
                System.out.println(conferenceRoom.getConfRoomId());
            }
        }

    }

    public Boolean checkSlot(ConferenceRoom conferenceRoom, int startTime, int endTime)
    {
        List<Slot> bookedSlots = conferenceRoom.getBookedSlots();

        if(bookedSlots ==  null || bookedSlots.size()== 0)
        {
            //bookedSlots.add(new Slot(startTime, endTime));
            return Boolean.TRUE;
        }
        else
        {
            for(Slot slot: bookedSlots)
            {
                if((endTime>slot.getStartTime() && endTime <slot.getEndTime()) ||
                        (startTime>slot.getStartTime() && startTime< slot.getEndTime()))
                {
                    return Boolean.FALSE;
                }
            }
        }
        //bookedSlots.add(new Slot(startTime, endTime));
        return Boolean.TRUE;
    }

}
